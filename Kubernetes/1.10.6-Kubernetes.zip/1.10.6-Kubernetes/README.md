Prereqs:
1.11 Cluster (Last tested on 1.11.2
1 Master
5 Private Agents

1. Run ./nonHA-k8s-install.sh
2. Follow instructions

WIP:
External Ingress with Traefik
HA option
Deeper automation
